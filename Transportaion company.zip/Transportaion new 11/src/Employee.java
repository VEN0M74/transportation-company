public class Employee extends User{
    public Employee(String username, String password, String id) {

        super(username, password, id);
    }

}
