public class Passenger extends User{
    public  Passenger(String username, String password, String id) {
        super(username, password, id);
    }
}
